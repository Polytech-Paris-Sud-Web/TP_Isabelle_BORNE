export interface Article {
  title : string,
  content : string,
  authors : string
};
